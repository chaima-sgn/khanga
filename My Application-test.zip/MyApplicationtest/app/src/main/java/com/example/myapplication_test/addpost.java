package com.example.myapplication_test;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class addpost extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addpost);

        EditText date = findViewById(R.id.Date);
        EditText time = findViewById(R.id.Time);
        EditText duration = findViewById(R.id.duration);
        EditText age = findViewById(R.id.age);
        EditText city = findViewById(R.id.city);
        EditText address = findViewById(R.id.address);
        EditText tel = findViewById(R.id.tel);
        EditText price = findViewById(R.id.price);

        MaterialButton submitbtn = findViewById(R.id.submitbtn);
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String date1 = date.getText().toString();
                String time1 = time.getText().toString();
                String duration1 = duration.getText().toString();
                String age1 = age.getText().toString();
                String city1 = city.getText().toString();
                String address1 = address.getText().toString();
                String tel1 = tel.getText().toString();
                String price1 = price.getText().toString();
                String datePattern = "^(0?[1-9]|[1-2][0-9]|3[0-1])/(0?[1-9]|1[0-2])/202[3-9]$|^31/(0?[13578]|1[02])/202[3-9]$|^30/(0?[469]|11)/202[3-9]$|^29/02/202[4-9]$";
                int ageInt = Integer.parseInt(age1);
                if (!date1.matches(datePattern)) {
                    date.setError("Date should be in this format JJ/MM/AAAA");
                    return;
                }
                if (!time1.matches("^([0-5][0-9]):([01][0-2])$")) {
                    time.setError("Time should be in this format mm:hh");
                    return;
                }
                if (TextUtils.isEmpty(duration1)) {
                    duration.setError("Duration should be left empty");
                    return;
                }
                if (ageInt < 1 && ageInt > 6) {

                    age.setError("check age!");
                    return;
                }
                if (TextUtils.isEmpty(city1)) {
                    city.setError("check city!");
                    return;
                }
                if (TextUtils.isEmpty(address1)) {
                    address.setError("check address!");
                    return;
                }
                if (TextUtils.isEmpty(tel1) || tel1.length() != 8 || tel1.startsWith("0")) {
                    tel.setError("Phone number should be of 8 numbers and should not start with zero");
                    return;
                }
                if (TextUtils.isEmpty(price1) || !TextUtils.isDigitsOnly(price1)) {
                    price.setError("Price should be a valid number and should not be empty!");
                    return;
                }

            }

            });


    }
}