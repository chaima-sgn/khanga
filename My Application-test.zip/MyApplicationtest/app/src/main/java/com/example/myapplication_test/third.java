package com.example.myapplication_test;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;


import com.google.android.material.button.MaterialButton;

public class third extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        TextView username = (TextView) findViewById(R.id.username1);
        TextView password = (TextView) findViewById(R.id.password);
        TextView tv = (TextView) findViewById(R.id.signin);
        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                    Toast.makeText(third.this, "login success", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(third.this, choose.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(third.this, "login failed!!", Toast.LENGTH_SHORT).show();
                }

            }

        });

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(third.this, sign_in1.class);
                startActivity(intent);


            }
        });
    }
}