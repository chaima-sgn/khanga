package com.example.myapplication_test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.material.button.MaterialButton;

public class sign_in1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in1);

        EditText username = findViewById(R.id.username1);
        EditText email = findViewById(R.id.email);
        EditText password = findViewById(R.id.password);
        EditText confirm = findViewById(R.id.confirm_pass);
        MaterialButton signinbtn = findViewById(R.id.signinbtn);

        signinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username1 = username.getText().toString();
                String email1 = email.getText().toString();
                String password1 = password.getText().toString();
                String confirmPassword = confirm.getText().toString();

                if (username1.length() < 7 || username1.isEmpty()) {
                    username.setError("Username should be shorter than 7 characters");
                    return;
                }

                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email1).matches()) {
                    email.setError("Please enter a valid email address");
                    return;
                }

                if (password1.isEmpty() || password1.length() < 8) {
                    password.setError("Password should not be empty and should be at least 8 characters long");
                    return;
                }

                if (!password1.equals(confirmPassword)) {
                    confirm.setError("Passwords do not match");
                    return;
                }

                Toast.makeText(sign_in1.this, "Sign-in successful", Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(sign_in1.this, choose.class);
                startActivity(intent);
            }

        });
    }
}
